
The file hdri-background-example.blend was created with Blender 2.93
and can be opened with that program.  See Appendix B, Section 4
of "Introduction to Computer Graphics", at
https://math.hws.edu/graphicsbook for more information about
the example.

The .blend file requires the three .jpg images that are in this 
directory.  The .jpg files are all free.  The background image,
old_hall_4k.jpg, is derived from an HDR image old_hall_4k.hdr,
that was downloaed from polyhaven.com.  The actual HDR image
gives a significantly better picture, but I converted it to a much
smaller .jpg file for this download.  (The hdr version is 25
megabytes compared to 2 megabytes for the jpg version.)

The file is set to use the Cycles renderer, with default settings 
except that the render is set to use NLM denoising (in the "Denosing"
section under "Sampling" in the Render Properties).

The settings for the Eevee renderer have been set to generate
a very similar image.

